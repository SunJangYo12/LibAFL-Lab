/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __ASM_SIGNAL_H
#define __ASM_SIGNAL_H
#define SA_RESTORER 0x04000000
#define MINSIGSTKSZ 5120
#define SIGSTKSZ 16384
#include <asm-generic/signal.h>
#endif
