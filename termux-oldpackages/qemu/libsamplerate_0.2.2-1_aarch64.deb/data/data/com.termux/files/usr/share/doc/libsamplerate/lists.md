---
layout: default
---

# Mailing Lists

There are currently two mailings lists for Secret Rabbit Code:

- **src-announce\@mega-nerd.com**  
  [Subscribe](mailto:src-announce-request@mega-nerd.com?subject=subscribe)

  A read only announcement list.
- **src\@mega-nerd.com**  
  [Subscribe](mailto:src-request@mega-nerd.com?subject=subscribe)

  A general list which will also carry all the email from the announce
  list. Posting to this list is restricted to subscribers.
